"""Offline audit of published history summaries; no network or model calls.
Inputs were manually transcribed from the pinned GitHub source in README.md.
Utility is a fraction in [0,1]; exported effects and intervals are percentage points.
"""
import csv
import random
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SEED, REPS = 2026091303, 20000
ARMS = ["direct", "staged2", "rewrite"]

def quantile(values, p):
    v = sorted(values)
    z = (len(v)-1)*p
    i,j = math.floor(z), math.ceil(z)
    return v[i] if i == j else v[i]+(z-i)*(v[j]-v[i])

def bootstrap(values):
    n = len(values)
    if not n:
        raise ValueError("No valid pairs.")
    rng = random.Random(SEED)
    means = [sum(values[rng.randrange(n)] for _ in range(n))/n for _ in range(REPS)]
    return sum(values)/n, quantile(means,.05), quantile(means,.95)

def main():
    with (ROOT/"history_inputs.csv").open(encoding="utf-8",newline="") as f:
        rows = list(csv.DictReader(f))
    if len(rows) != 48 or len({(r["reader"],r["history_id"]) for r in rows}) != 48:
        raise ValueError("Expected 48 distinct reader-history records.")
    for r in rows:
        for arm in ARMS:
            key = "U_"+arm
            r[key] = float(r[key]) if r[key] else None
            if r[key] is not None and not 0 <= r[key] <= 1:
                raise ValueError("Utility out of range.")
    result=[]
    for reader in ["R1","R2"]:
        rr=[r for r in rows if r["reader"]==reader]
        for mode in ["three_arm_complete","pair_specific"]:
            for name,a,b in [("SD","staged2","direct"),("RD","rewrite","direct"),
                              ("SR","staged2","rewrite")]:
                required=ARMS if mode=="three_arm_complete" else [a,b]
                usable=[r for r in rr if all(r["U_"+x] is not None for x in required)]
                deltas=[r["U_"+a]-r["U_"+b] for r in usable]
                m,lo,hi=bootstrap(deltas)
                result.append(dict(reader=reader,mode=mode,contrast=name,n=len(deltas),
                    mean_pp=100*m,ci90_low_pp=100*lo,ci90_high_pp=100*hi,
                    bootstrap_seed=SEED,bootstrap_replicates=REPS))
    with (ROOT/"paired_reanalysis.csv").open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(result[0]))
        w.writeheader();w.writerows(result)
    for r in result:
        print("{reader} {mode} {contrast}: n={n}, {mean_pp:.3f} pp "
              "[{ci90_low_pp:.3f}, {ci90_high_pp:.3f}]".format(**r))

if __name__ == "__main__":
    main()
